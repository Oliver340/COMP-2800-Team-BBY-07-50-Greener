$('#maingoal').barfiller({

    // color of bar
    barColor: '#16b597',

    // shows a tooltip
    tooltip: true,

    // duration in ms
    duration: 1000,

    // re-animate on resize
    animateOnResize: true,

    // custom symbol
    symbol: "%"

});
